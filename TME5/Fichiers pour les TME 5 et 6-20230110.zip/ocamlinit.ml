#use "topfind";;
#mod_use "_build/default/syntax.ml";;
#mod_use "_build/default/yaccParser.ml";;
#mod_use "_build/default/lexer.ml";;
#mod_use "_build/default/printer.ml";;
#mod_use "_build/default/input.ml";;

open Syntax
open Input
open Printer
    
